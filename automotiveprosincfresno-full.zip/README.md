# Automotive Pros Inc. Website (Fresno)

Deploy with GitHub + Vercel

## Deploy
1) Create a GitHub repo (e.g. automotiveprosincfresno) and push these files.
2) In Vercel → New Project → Import GitHub Repository → select this repo → Deploy.
3) Add domains in Vercel → Settings → Domains:
   - automotiveprosincfresno.com
   - www.automotiveprosincfresno.com
4) In Squarespace DNS, set:
   - A @ → 76.76.21.21
   - CNAME www → cname.vercel-dns.com

SSL is automatic.
